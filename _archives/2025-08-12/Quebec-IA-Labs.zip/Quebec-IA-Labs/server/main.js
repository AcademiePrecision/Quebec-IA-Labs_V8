// 🚀 QUÉBEC IA LABS - SERVEUR INTELLIGENT V6
// ==========================================
// Version: 6.0.0 - Claude AI + Marcel Trainer intégré
// Date: 2025-08-10

const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

// 📦 Import des modules
let MarcelTrainer = null;
let ContextAnalyzer = null;
let RelationshipData = null;

try {
  MarcelTrainer = require('./marcel-trainer');
  console.log('✅ MarcelTrainer chargé');
} catch (error) {
  console.log('⚠️ MarcelTrainer non disponible');
}

try {
  ContextAnalyzer = require('./context-analyzer');
  console.log('✅ ContextAnalyzer chargé');
} catch (error) {
  console.log('⚠️ ContextAnalyzer non disponible');
}

try {
  RelationshipData = require('./relationship-data');
  console.log('✅ RelationshipData chargé');
} catch (error) {
  console.log('⚠️ RelationshipData non disponible');
}

// 🧠 Intelligence artificielle Claude
let anthropic = null;
if (process.env.ANTHROPIC_API_KEY) {
  try {
    const Anthropic = require('@anthropic-ai/sdk');
    anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY
    });
    console.log('✅ Claude AI configuré');
  } catch (error) {
    console.log('⚠️ Claude AI non disponible:', error.message);
  }
}

// 📊 Métriques
const performanceMetrics = {
  startTime: Date.now(),
  totalCalls: 0,
  successfulCalls: 0,
  failedCalls: 0
};

// 💾 Sessions avec mémoire complète
const callSessions = new Map();

// 🧠 Initialisation unique de ContextAnalyzer
let contextAnalyzer = null;
if (ContextAnalyzer) {
  try {
    contextAnalyzer = new ContextAnalyzer();
    console.log('✅ ContextAnalyzer initialisé');
  } catch (error) {
    console.log('⚠️ Erreur ContextAnalyzer:', error.message);
  }
}

// 📅 DISPONIBILITÉS DU SALON
const SALON_CONFIG = {
  horaires: {
    lundi: "FERMÉ",
    mardi: { ouverture: "9h", fermeture: "18h", creneaux: ["9h", "10h", "11h", "14h", "15h", "16h", "17h"] },
    mercredi: { ouverture: "9h", fermeture: "18h", creneaux: ["9h", "10h", "11h", "14h", "15h", "16h", "17h"] },
    jeudi: { ouverture: "9h", fermeture: "18h", creneaux: ["9h", "10h", "11h", "14h", "15h", "16h", "17h"] },
    vendredi: { ouverture: "9h", fermeture: "18h", creneaux: ["9h", "10h", "11h", "14h", "15h", "16h", "17h"] },
    samedi: { ouverture: "9h", fermeture: "16h", creneaux: ["9h", "10h", "11h", "14h", "15h"] },
    dimanche: "FERMÉ"
  },
  barbiers: {
    marco: { specialite: "barbe", jours: ["mardi", "jeudi", "samedi"] },
    jessica: { specialite: "coupe femme", jours: ["mercredi", "vendredi", "samedi"] },
    tony: { specialite: "coupe homme", jours: ["mardi", "mercredi", "jeudi", "vendredi"] }
  },
  services: {
    "coupe": { prix: 35, duree: 30 },
    "barbe": { prix: 25, duree: 20 },
    "coupe et barbe": { prix: 55, duree: 45 },
    "coloration": { prix: 80, duree: 60 }
  }
};

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// 🤖 Fonction pour analyser avec Claude AI
async function analyzeWithClaude(userInput, sessionContext) {
  if (!anthropic) {
    return null;
  }

  try {
    const systemPrompt = `Tu es un assistant de réservation pour un salon de coiffure. 

Contexte actuel de la conversation:
- Service demandé: ${sessionContext.service || 'non défini'}
- Jour demandé: ${sessionContext.date || 'non défini'}
- Heure demandée: ${sessionContext.time || 'non défini'}
- Barbier préféré: ${sessionContext.barbier || 'non défini'}
- Nom client: ${sessionContext.name || 'non défini'}

Horaires du salon:
- Lundi: FERMÉ
- Mardi à Vendredi: 9h-18h
- Samedi: 9h-16h
- Dimanche: FERMÉ

Le client dit: "${userInput}"

Analyse cette phrase et réponds en JSON avec:
{
  "intention": "booking|pricing|hours|disponibilites|autre",
  "elements_extraits": {
    "service": "coupe|barbe|coupe et barbe|coloration|null",
    "jour": "lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche|null",
    "heure": "9h|10h|11h|14h|15h|16h|17h|null",
    "barbier": "marco|jessica|tony|null"
  },
  "validation": {
    "jour_valide": true/false,
    "heure_valide": true/false,
    "probleme": "description du problème si invalide"
  },
  "prochaine_question": "Quelle information manque pour compléter la réservation?"
}`;

    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 200,
      messages: [
        { role: "user", content: systemPrompt }
      ],
      temperature: 0.3
    });

    const responseText = response.content[0].text;
    console.log("🤖 Claude analyse:", responseText);

    // Parser le JSON de Claude
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (error) {
    console.error("❌ Erreur Claude AI:", error.message);
  }

  return null;
}

// 🎯 Fonction pour générer une réponse intelligente
function generateSmartResponse(session, userInput) {
  const text = userInput.toLowerCase();
  const context = session.context || {};

  // Vérifier les disponibilités
  if (text.includes("disponibilit") || text.includes("dispo") || text.includes("libre")) {
    if (context.date) {
      const jour = context.date.toLowerCase();
      if (SALON_CONFIG.horaires[jour] === "FERMÉ") {
        return `Désolé, nous sommes fermés le ${jour}. Je peux vous proposer mardi, mercredi, jeudi, vendredi ou samedi.`;
      } else if (SALON_CONFIG.horaires[jour]) {
        const creneaux = SALON_CONFIG.horaires[jour].creneaux.slice(0, 3).join(", ");
        return `Pour ${jour}, j'ai ${creneaux}. Quelle heure préférez-vous?`;
      }
    } else {
      return "Je peux vous proposer mardi à samedi. Quel jour préférez-vous?";
    }
  }

  // Validation du jour
  if (context.intent === 'booking') {
    // Détecter le jour
    const jours = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"];
    const jourTrouve = jours.find(jour => text.includes(jour));

    if (jourTrouve) {
      if (jourTrouve === "lundi" || jourTrouve === "dimanche") {
        return `Désolé, nous sommes fermés le ${jourTrouve}. Je peux vous proposer mardi à samedi. Quel jour?`;
      }
      context.date = jourTrouve;
      session.context = context;
      return `Parfait pour ${jourTrouve}. J'ai des disponibilités à 9h, 14h ou 16h. Quelle heure vous convient?`;
    }

    // Détecter l'heure
    const heureMatch = text.match(/(\d{1,2})\s*(h|heure)/);
    if (heureMatch) {
      const heure = parseInt(heureMatch[1]);

      // Validation de l'heure
      if (heure < 9 || heure > 18) {
        return `Désolé, nous sommes ouverts de 9h à 18h. Je peux vous proposer 9h, 14h ou 16h.`;
      }

      context.time = `${heure}h`;
      session.context = context;

      // Si on a tout, demander le nom
      if (context.service && context.date && context.time) {
        return `Excellent! ${context.service} ${context.date} à ${context.time}. Votre nom complet pour confirmer?`;
      }
    }

    // Gérer les demandes de barbier
    if (text.includes("barbier") || text.includes("coiffeur")) {
      if (context.date === "mardi" || context.date === "jeudi") {
        return "Pour ce jour, j'ai Marco (spécialiste barbe) ou Tony (coupes hommes). Préférence?";
      } else if (context.date === "mercredi" || context.date === "vendredi") {
        return "Pour ce jour, j'ai Jessica (coupes femmes) ou Tony (coupes hommes). Préférence?";
      } else if (context.date === "samedi") {
        return "Samedi, toute l'équipe est là: Marco, Jessica et Tony. Préférence?";
      } else {
        return "Nos barbiers sont Marco, Jessica et Tony. D'abord, quel jour souhaitez-vous?";
      }
    }
  }

  return null;
}

console.log(`
🚀 QUÉBEC IA LABS - SERVEUR INTELLIGENT V6
===========================================
Version: 6.0.0
Port: ${PORT}
Claude AI: ${anthropic ? "✅" : "❌"}
Twilio: ${process.env.TWILIO_PHONE_NUMBER || "Non configuré"}
ContextAnalyzer: ${contextAnalyzer ? "✅" : "❌"}
===========================================
`);

// ==============================================
// 🏥 HEALTH CHECK
// ==============================================

app.get("/", (req, res) => {
  const uptime = Date.now() - performanceMetrics.startTime;
  const uptimeMinutes = Math.floor(uptime / (1000 * 60));

  res.json({
    service: "Québec IA Labs - Réceptionniste IA",
    status: "active",
    version: "6.0.0",
    intelligence: anthropic ? "Claude AI" : "Pattern matching",
    uptime: `${uptimeMinutes} minutes`,
    performance: {
      totalCalls: performanceMetrics.totalCalls,
      successRate: `${Math.round((performanceMetrics.successfulCalls / performanceMetrics.totalCalls) * 100) || 0}%`
    }
  });
});

// ==============================================
// 📞 WEBHOOK PRINCIPAL - ACCUEIL
// ==============================================

app.post("/webhook/twilio/voice", async (req, res) => {
  const { From, CallSid } = req.body;
  console.log(`\n📞 NOUVEL APPEL: ${From} [${CallSid}]`);
  performanceMetrics.totalCalls++;

  // Créer session avec contexte complet
  callSessions.set(CallSid, {
    phone: From,
    startTime: Date.now(),
    context: {},
    history: []
  });

  try {
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="fr-CA" voice="Polly.Mathieu">
    <prosody rate="105%">
      Bonjour, salon Marcel. Comment puis-je vous aider?
    </prosody>
  </Say>
  <Gather 
    input="speech dtmf" 
    timeout="4" 
    speechTimeout="1.5"
    language="fr-CA" 
    action="/webhook/twilio/process" 
    method="POST"
    enhanced="true"
    profanityFilter="false"
  >
    <Say></Say>
  </Gather>
</Response>`;

    console.log("✅ Accueil envoyé");
    performanceMetrics.successfulCalls++;
    res.set("Content-Type", "text/xml");
    res.send(twiml);

  } catch (error) {
    console.error("❌ Erreur:", error.message);
    res.status(500).send("Erreur");
  }
});

// ==============================================
// 🎤 TRAITEMENT INTELLIGENT
// ==============================================

app.post("/webhook/twilio/process", async (req, res) => {
  const { SpeechResult, CallSid, Confidence } = req.body;
  const session = callSessions.get(CallSid) || { context: {}, history: [] };

  console.log(`\n🎤 CLIENT DIT: "${SpeechResult}" (Confiance: ${Confidence})`);
  console.log(`   Session actuelle:`, JSON.stringify(session.context));

  // Ajouter à l'historique
  if (SpeechResult) {
    session.history.push({ user: SpeechResult, timestamp: Date.now() });
  }

  try {
    let response = "";
    let nextAction = "/webhook/twilio/process";

    if (!SpeechResult || SpeechResult === "undefined") {
      response = "Je ne vous entends pas. Pouvez-vous répéter?";
    } else {
      const text = SpeechResult.toLowerCase();

      // Analyser avec Claude AI si disponible
      if (anthropic) {
        const claudeAnalysis = await analyzeWithClaude(SpeechResult, session.context);
        if (claudeAnalysis) {
          console.log("🤖 Claude comprend:", claudeAnalysis);

          // Mettre à jour le contexte avec l'analyse Claude
          if (claudeAnalysis.elements_extraits) {
            Object.keys(claudeAnalysis.elements_extraits).forEach(key => {
              if (claudeAnalysis.elements_extraits[key] && claudeAnalysis.elements_extraits[key] !== 'null') {
                session.context[key] = claudeAnalysis.elements_extraits[key];
              }
            });
          }

          // Validation intelligente
          if (claudeAnalysis.validation && claudeAnalysis.validation.probleme) {
            response = claudeAnalysis.validation.probleme;
          }
        }
      }

      // Si pas de réponse Claude, utiliser la logique intelligente
      if (!response) {
        response = generateSmartResponse(session, SpeechResult);
      }

      // Si toujours pas de réponse, utiliser la logique de base
      if (!response) {
        // Détection d'intention
        if (text.includes("rendez-vous") || text.includes("rdv") || text.includes("réserver")) {
          session.context.intent = 'booking';
          if (!session.context.service) {
            response = "Quel service désirez-vous? Coupe, barbe, ou les deux?";
          } else if (!session.context.date) {
            response = "Pour quel jour? Nous sommes ouverts mardi à samedi.";
          } else if (!session.context.time) {
            const jour = session.context.date;
            const dispo = SALON_CONFIG.horaires[jour];
            if (dispo && dispo.creneaux) {
              response = `Pour ${jour}, j'ai: ${dispo.creneaux.slice(0, 3).join(", ")}. Quelle heure?`;
            } else {
              response = "À quelle heure préférez-vous?";
            }
          } else {
            response = "Votre nom complet pour confirmer?";
            nextAction = "/webhook/twilio/confirm";
          }
        }
        else if (text.includes("prix") || text.includes("coût") || text.includes("combien")) {
          response = "Coupe 35$, barbe 25$, coupe et barbe 55$, coloration 80$. Voulez-vous réserver?";
        }
        else if (text.includes("horaire") || text.includes("ouvert")) {
          response = "Ouvert mardi à samedi, 9h à 18h. Fermé dimanche et lundi. Voulez-vous un rendez-vous?";
        }
        else if (text.includes("coupe") && !text.includes("barbe")) {
          session.context.service = "coupe";
          session.context.intent = 'booking';
          response = "Coupe notée. Pour quel jour?";
        }
        else if (text.includes("barbe") && !text.includes("coupe")) {
          session.context.service = "barbe";
          session.context.intent = 'booking';
          response = "Barbe notée. Pour quel jour?";
        }
        else if (text.includes("coupe") && text.includes("barbe")) {
          session.context.service = "coupe et barbe";
          session.context.intent = 'booking';
          response = "Coupe et barbe, parfait. Pour quel jour?";
        }
        else if (text.includes("oui")) {
          if (session.history.length > 0) {
            const lastBot = session.history[session.history.length - 1];
            if (lastBot && lastBot.bot && lastBot.bot.includes("réserver")) {
              session.context.intent = 'booking';
              response = "Quel service voulez-vous?";
            } else {
              response = "D'accord. Que puis-je faire pour vous?";
            }
          }
        }
        else {
          response = "Je n'ai pas compris. Voulez-vous un rendez-vous, les prix, ou les horaires?";
        }
      }
    }

    // Sauvegarder l'historique de la réponse
    session.history.push({ bot: response, timestamp: Date.now() });
    callSessions.set(CallSid, session);

    console.log(`   → Réponse: "${response}"`);
    console.log(`   → Contexte mis à jour:`, JSON.stringify(session.context));

    // Construire TwiML
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="fr-CA" voice="Polly.Mathieu">
    <prosody rate="105%">
      ${response}
    </prosody>
  </Say>
  <Gather 
    input="speech dtmf" 
    timeout="4"
    speechTimeout="1.5" 
    language="fr-CA" 
    action="${nextAction}" 
    method="POST"
    enhanced="true"
    profanityFilter="false"
  >
    <Say></Say>
  </Gather>
</Response>`;

    res.set("Content-Type", "text/xml");
    res.send(twiml);

  } catch (error) {
    console.error("❌ Erreur traitement:", error);
    res.status(500).send("Erreur");
  }
});

// ==============================================
// ✅ CONFIRMATION FINALE
// ==============================================

app.post("/webhook/twilio/confirm", async (req, res) => {
  const { SpeechResult, CallSid } = req.body;
  const session = callSessions.get(CallSid) || { context: {} };

  console.log(`\n✅ CONFIRMATION - Nom: ${SpeechResult}`);
  session.context.name = SpeechResult;

  const { service, date, time } = session.context;
  const summary = `Parfait ${SpeechResult}. Je confirme votre ${service || 'rendez-vous'} ${date || ''} à ${time || ''}. À bientôt!`;

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="fr-CA" voice="Polly.Mathieu">
    <prosody rate="105%">
      ${summary}
    </prosody>
  </Say>
  <Pause length="1"/>
  <Say language="fr-CA" voice="Polly.Mathieu">Merci et bonne journée!</Say>
  <Hangup/>
</Response>`;

  // Log final
  console.log(`📊 Réservation complète:`, session.context);

  // Nettoyer
  callSessions.delete(CallSid);

  res.set("Content-Type", "text/xml");
  res.send(twiml);
});

// ==============================================
// 📱 WEBHOOK SMS
// ==============================================

app.post("/webhook/twilio/sms", (req, res) => {
  console.log("📱 SMS:", req.body.From, "-", req.body.Body);

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>Merci! Nous vous rappellerons bientôt. Pour plus rapide, appelez ${process.env.TWILIO_PHONE_NUMBER}. - Salon Marcel</Message>
</Response>`;

  res.set("Content-Type", "text/xml");
  res.send(twiml);
});

// ==============================================
// 🚀 DÉMARRAGE
// ==============================================

app.listen(PORT, "0.0.0.0", () => {
  console.log(`
🎉 SERVEUR INTELLIGENT V6 ACTIF
=================================
✅ Port: ${PORT}
✅ Intelligence: ${anthropic ? 'Claude AI' : 'Logique avancée'}
✅ Voix: Polly.Mathieu (105% vitesse)
✅ ContextAnalyzer: ${contextAnalyzer ? 'Actif' : 'Inactif'}

📞 ${process.env.TWILIO_PHONE_NUMBER || '+15817101240'}

Améliorations V6:
- Claude AI pour analyse intelligente
- Validation jours/heures (lundi=fermé)
- Proposition de créneaux disponibles
- Mémoire de session complète
- Historique de conversation
- Détection barbiers disponibles
- Voix plus rapide et naturelle
  `);
});

module.exports = app;