// index.js - Point d'entrée Replit
console.log('🚀 Démarrage Quebec IA Labs sur Replit...');
require('./server/main.js');